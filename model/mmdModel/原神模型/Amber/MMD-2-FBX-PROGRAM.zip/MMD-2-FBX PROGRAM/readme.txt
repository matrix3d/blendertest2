New TRUEBONES MMD to FBX converter. Now features Drag and Drop Ease of use.

Instructions, simply drag and drop any VMD file (motion) and or PMX,PMD character file (model).

Wait Patiently...

MMD converter will create a skeleton with motion data and character skin In FBX format with MORPHS!. 

Drag Multiple VMD MOTION FILES along with any PMX Model file to make a pak of motions with (on) that specific character.

NEW! You can now mix any PMD or PMX Character with any VMD MOTION!

THAT MEANS LITERALLY MILLIONS OF COMBINATIONS ARE POSSIBLE!

NOW YOU CAN CREATE MOTION PAKS , not just individual motions.

To download thousands of VMD and PMX files, Search {MMD} motion download on Youtube.

Thanks and Cheers from http://truebones.com

Disclaimer: MMD to FBX/BVH converter is protected by copyright law, Re-distribution or unauthorized use is strictly prohibited. 

P.S. Download free companion programs MIKUMIKU DANCE English Version and PMX Editor to further enhance your animation creation experience.