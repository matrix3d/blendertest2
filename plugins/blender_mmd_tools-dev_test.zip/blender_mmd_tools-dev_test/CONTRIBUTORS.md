Original author
- sugiany

Maintainer
- powroupi

Contributors
- iRi-E
- lordscales91
- Pixiy
- r1cebank
- nagadomi
- ptrthomas
- stefnotch
- qwertychouskie
- ChennyBaBy
- Darkblader24
- aoowweenn
